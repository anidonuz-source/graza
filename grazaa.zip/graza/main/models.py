from django.db import models

class Price(models.Model):
    usd = models.FloatField()
    ton = models.FloatField()
    nft = models.FloatField()
    updated = models.DateTimeField(auto_now=True)

class Support(models.Model):
    name = models.CharField(max_length=100)
    message = models.TextField()
    created = models.DateTimeField(auto_now_add=True)

class Music(models.Model):
    title = models.CharField(max_length=200)
    artist = models.CharField(max_length=200)
    file = models.FileField(upload_to="music/")