import requests

def get_usd():
    url = "https://cbu.uz/uz/arkhiv-kursov-valyut/json/"
    data = requests.get(url).json()
    for i in data:
        if i["Ccy"] == "USD":
            return float(i["Rate"])

def get_ton():
    url = "https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd"
    data = requests.get(url).json()
    return data["the-open-network"]["usd"]