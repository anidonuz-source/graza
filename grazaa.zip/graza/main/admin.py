from django.contrib import admin
from .models import Price, Support, Music

admin.site.register(Price)
admin.site.register(Support)
admin.site.register(Music)