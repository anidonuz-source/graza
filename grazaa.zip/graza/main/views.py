from django.shortcuts import render, redirect
from .models import Music, Support
from .services import get_usd, get_ton

def home(request):

    usd = get_usd()
    ton = get_ton()

    price = {
        "usd": usd,
        "ton": ton,
        "nft": 0.0
    }

    music = Music.objects.all()

    return render(request, "index.html", {
        "price": price,
        "music": music
    })

def support(request):

    if request.method == "POST":

        name = request.POST["name"]
        message = request.POST["message"]

        Support.objects.create(name=name, message=message)

        return redirect("/")

    return render(request, "support.html")